package com.yb.yummy_book.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.math.BigInteger;
import java.util.List;
import lombok.Data;


@Data
@Entity
@Table(name = "users")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private BigInteger userId;

	private String username;
	private String email;
	private String passwordHash;
	private String profileImage;
	private String bio;

	@OneToMany(mappedBy = "createdBy")
	private List<Recipe> recipes;

	@OneToMany(mappedBy = "user")
	private List<Post> posts;

	@OneToMany(mappedBy = "user")
	private List<Comment> comments;

	@OneToMany(mappedBy = "followerUser")
	private List<Follower> followers;

	@OneToMany(mappedBy = "followedUser")
	private List<Follower> following;
}