package com.yb.yummy_book;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YummyBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(YummyBookApplication.class, args);
	}

}
