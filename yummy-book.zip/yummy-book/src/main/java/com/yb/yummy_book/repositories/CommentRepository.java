package com.yb.yummy_book.repositories;

import com.yb.yummy_book.model.Comment;
import com.yb.yummy_book.model.User;
import java.math.BigInteger;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommentRepository extends JpaRepository<Comment, BigInteger> {

}
