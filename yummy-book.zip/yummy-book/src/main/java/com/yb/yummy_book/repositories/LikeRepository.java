package com.yb.yummy_book.repositories;

import com.yb.yummy_book.model.Like;
import com.yb.yummy_book.model.User;
import java.math.BigInteger;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LikeRepository extends JpaRepository<Like, BigInteger> {

}
