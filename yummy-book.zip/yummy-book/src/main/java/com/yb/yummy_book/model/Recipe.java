package com.yb.yummy_book.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import java.math.BigInteger;
import java.util.List;
import lombok.Data;

@Data
@Entity
public class Recipe {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private BigInteger recipeId;

	private String title;

	private String description;

	@Lob
	private String ingredients;

	@Lob
	private String instructions;

	private String imageUrl;

	@ManyToOne
	@JoinColumn(name = "created_by")
	private User createdBy;

	@OneToMany(mappedBy = "recipe")
	private List<Post> posts;
}