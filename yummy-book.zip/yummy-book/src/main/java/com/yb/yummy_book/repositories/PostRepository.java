package com.yb.yummy_book.repositories;

import com.yb.yummy_book.model.Post;
import java.math.BigInteger;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PostRepository extends JpaRepository<Post, BigInteger> {

}
