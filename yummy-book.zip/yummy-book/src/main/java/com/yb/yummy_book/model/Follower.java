package com.yb.yummy_book.model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import java.math.BigInteger;
import lombok.Data;

@Data
@Entity
public class Follower {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private BigInteger followerId;

	@ManyToOne
	@JoinColumn(name = "follower_user_id")
	private User followerUser;

	@ManyToOne
	@JoinColumn(name = "followed_user_id")
	private User followedUser;
}