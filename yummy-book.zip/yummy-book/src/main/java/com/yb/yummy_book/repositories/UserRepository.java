package com.yb.yummy_book.repositories;

import com.yb.yummy_book.model.User;
import java.math.BigInteger;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, BigInteger> {
	Optional<User> findByEmail(String email);
}
