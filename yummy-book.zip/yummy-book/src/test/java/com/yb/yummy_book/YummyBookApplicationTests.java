package com.yb.yummy_book;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YummyBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
